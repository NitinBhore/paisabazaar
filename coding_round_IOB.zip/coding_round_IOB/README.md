# General Guidelines:

* Solution will be evaluated based on logic, code quality, comments, docstring and assignment completion within time limit.
* Although we prefer optimized code but don't put too much focus on optimization/performance of the code for this assignment.
* Adding unit tests will be plus and will showcase good software engineering practice.
* Feel free to stackoverflow and google. just make sure you dont copy paste code blindly.
